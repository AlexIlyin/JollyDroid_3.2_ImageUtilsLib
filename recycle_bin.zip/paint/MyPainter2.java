package com.alexilyin.android.a32_imageutilslib.paint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.support.annotation.ColorInt;
import android.view.Surface;

import java.util.Stack;

/**
 * Created by user on 29.03.16.
 */
public class MyPainter2 implements IPainter {

    @Override
    public void actionFillRegion(float x, float y, @ColorInt int MaskColor) {

    }

    int paintColor;
    public Context mainActivity;

    Bitmap bitmap;
    Surface surface;
    private int bitmapWidth;
    private int bitmapHeight;


    @Override
    public void setPaintColor(@ColorInt int color) {
        paintColor = color;
    }

    @Override
    public void putSurface(Surface surface) {
        this.surface = surface;
    }

    @Override
    public void putBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
        bitmapWidth = bitmap.getWidth();
        bitmapHeight = bitmap.getHeight();
    }

    @Override
    public void actionPaintFree(float x, float y) {

    }

// =============================================================================================
// Paint Inside Region
// =============================================================================================

    int lastX, lastY;
    @ColorInt
    int seekColor;
    int dotRadius = 50;

    @Override
    public void pickStartPoint(float x, float y) {
        lastX = Math.round(x);
        lastY = Math.round(y);
        seekColor = bitmap.getPixel(lastX, lastY);
    }

    @Override
    public void actionPaintInsideRegion(float touchX, float touchY) {
        assert bitmap != null;

        int x = Math.round(touchX);
        int y = Math.round(touchY);

        Bitmap maskBitmap = Bitmap.createBitmap(bitmap);


        seekColor = bitmap.getPixel(x, y);

        paintDot(x, y);
    }

    private void paintDot(int x, int y) {

        for (int dy = 0; dy <= dotRadius; dy++) {

            int dx = (int) Math.round(Math.sqrt(Math.pow(dotRadius, 2) - Math.pow(dy, 2)));
            paintDotPartLine(x, y + dy, dx);
            paintDotPartLine(x, y + dy, -dx);
            paintDotPartLine(x, y - dy, dx);
            paintDotPartLine(x, y - dy, -dx);
        }
    }

    //        ooooooo
    //     oo         oo
    //   o               o
    //  o                 o
    //  o        X        o
    //  o                 o
    //   o       ========o
    //     oo         oo
    //        ooooooo

    void paintDotPartLine(int startX, int startY, int length) {

        if ((startY < 0 || startY >= bitmapHeight)) // Check image borders
            return;

//        if (length == 0) {
//            paintDotPixel(startX, startY);
//            return;
//        }

        int dx = (int) Math.signum(length);
        if (length == 0) {
            dx = 1;
        }
        length = Math.abs(length);
        for (int x = 0; -length <= x && x <= +length; x += dx) {

            if (startX + x < 0 || startX + x >= bitmapWidth)  // Check image borders
                return;

            int color = bitmap.getPixel(startX + x, startY);

            if (isEqualColor(color, seekColor)) // Paint on seekColor
                paintDotPixel(startX + x, startY);
            else if (!isEqualColor(color, paintColor)) // Continue on paintColor
                return;  // Stop painting line if other colors
        }
    }

    void paintDotPixel(int x, int y) {
        bitmap.setPixel(x, y, paintColor);
    }


// =============================================================================================
// Fill Region
// =============================================================================================

    Stack<Segment> segmentStack = new Stack<>();

//    @Override
    public void actionFillRegion(float x, float y) {
        actionFillRegion(Math.round(x), Math.round(y));
    }


    public void actionFillRegion(int init_x, int init_y) {

        assert bitmap != null;

        @ColorInt
        int seekColor = bitmap.getPixel(init_x, init_y);

        // If touch same-colored pixel, do nothing
        if (seekColor == paintColor)
            return;

        // Initial segment
        segmentStack.empty();
        segmentStack.push(
                new Segment(init_x, init_y)
                        .extendLeftBorder()
                        .extendRightBorder()
        );
//int _counter = 0;
        // Loop over stack
        while (!segmentStack.empty()) {
//_counter++;

//            _debug_sleep(20);
//            _debug_paintSurface();
            Segment next = segmentStack.pop();
            next.paint(paintColor);

            if ((next.direction == FillDirection.UP || next.direction == FillDirection.BOTH) &&
                    next.y - 1 >= 0)
                checkLine(next.leftX, next.rightX, next.y - 1, seekColor, FillDirection.UP);

            if ((next.direction == FillDirection.DOWN || next.direction == FillDirection.BOTH) &&
                    next.y + 1 < bitmapHeight)
                checkLine(next.leftX, next.rightX, next.y + 1, seekColor, FillDirection.DOWN);
        }
//Log.d("happy", "Segments count: " + _counter);

    }

    // Split line to Segments and push to stack
    private void checkLine(int leftX, int rightX, int y, @ColorInt int seekColor, FillDirection direction) {

        Segment tmpSegment = null;

        // checking line
        for (int x = leftX; x <= rightX; x++) {

            // Open segment
            if (tmpSegment == null &&   // no opened segment
                    isEqualColor(x, y, seekColor)) {   // equal color found

                // Create new segment
                tmpSegment = new Segment(x, y);
            }

            // Close segment
            if (tmpSegment != null &&   // inside segment
                    (!isEqualColor(x, y, seekColor) || x == rightX)) {
                // right border found || reached last pixel

                // Close segment and push into stack
                tmpSegment.rightX = x - 1;
                tmpSegment
                        .extendLeftBorder()
                        .extendRightBorder();

                if (tmpSegment.leftX < leftX || tmpSegment.rightX > rightX)
                    tmpSegment.direction = FillDirection.BOTH;
                else tmpSegment.direction = direction;

                segmentStack.push(tmpSegment);
                tmpSegment = null;
            }
        }
    }

    private boolean isEqualColor(int x, int y, @ColorInt int color) {
        return isEqualColor(bitmap.getPixel(x, y), color);
    }

    private boolean isEqualColor(@ColorInt int color1, @ColorInt int color2) {
        return color1 == color2;
    }

// =============================================================================================
// Inner Classes
// =============================================================================================

    enum FillDirection {UP, DOWN, BOTH}

    // Segment is a horizontal 1px line filled with single color
    private class Segment {

        int leftX;
        int rightX;
        int y;
        FillDirection direction;

        public Segment(int leftX, int rightX, int y, FillDirection direction) {
            this.direction = direction;
            this.y = y;
            this.rightX = rightX;
            this.leftX = leftX;
        }

        public Segment(int x, int y) {
            this(x, x, y, FillDirection.BOTH);
        }

        public Segment(int leftX, int rightX, int y) {
            this(leftX, rightX, y, FillDirection.BOTH);
        }

        private Segment extendLeftBorder() {
            int color = bitmap.getPixel(leftX, y);
            while (leftX - 1 >= 0 &&
                    isEqualColor(leftX - 1, y, color)) {
                leftX--;
            }
            return this;
        }

        private Segment extendRightBorder() {
            int color = bitmap.getPixel(rightX, y);
            while (rightX + 1 < bitmapWidth &&
                    isEqualColor(rightX + 1, y, color)) {
                rightX++;
            }
            return this;
        }

        private Segment paint(@ColorInt int color) {
            for (int x = leftX; x <= rightX; x++)
                bitmap.setPixel(x, y, color);
            return this;
        }

    }


// =============================================================================================
// Debug methods
// =============================================================================================

    void _debug_sleep(int ms) {
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    void _debug_paintSurface() {
        Canvas canvas = surface.lockCanvas(null);
        canvas.drawBitmap(bitmap, 0, 0, null);
        surface.unlockCanvasAndPost(canvas);

    }

}