package com.alexilyin.android.a32_imageutilslib.paint;

import android.graphics.Bitmap;
import android.support.annotation.ColorInt;
import android.util.Log;

import java.util.Stack;

/**
 * Created by user on 29.03.16.
 */
public class MyPainter3 {


//    int paintColor;
//    public Context mainActivity;
//
//    Bitmap bitmap;
//    Surface surface;
//    private int bitmapWidth;
//    private int bitmapHeight;


//    @Override
//    public void setPaintColor(@ColorInt int color) {
//        paintColor = color;
//    }
//
//    @Override
//    public void putSurface(Surface surface) {
//        this.surface = surface;
//    }
//
//    @Override
//    public void putBitmap(Bitmap bitmap) {
//        this.bitmap = bitmap;
//        bitmapWidth = bitmap.getWidth();
//        bitmapHeight = bitmap.getHeight();
//    }
//
//    @Override
//    public void actionPaintFree(float x, float y) {
//
//    }

// =============================================================================================
// Paint Inside Region
// =============================================================================================

//    int lastX, lastY;
//    @ColorInt
//    int seekColor;
//    int dotRadius = 50;
//
//    @Override
//    public void pickStartPoint(float x, float y) {
//        lastX = Math.round(x);
//        lastY = Math.round(y);
//        seekColor = bitmap.getPixel(lastX, lastY);
//    }
//
//    @Override
//    public void actionPaintInsideRegion(float touchX, float touchY) {
//        assert bitmap != null;
//
//        int x = Math.round(touchX);
//        int y = Math.round(touchY);
//
//        Bitmap maskBitmap = Bitmap.createBitmap(bitmap);
//
//
//        seekColor = bitmap.getPixel(x, y);
//
//        paintDot(x, y);
//    }
//
//    private void paintDot(int x, int y) {
//
//        for (int dy = 0; dy <= dotRadius; dy++) {
//
//            int dx = (int) Math.round(Math.sqrt(Math.pow(dotRadius, 2) - Math.pow(dy, 2)));
//            paintDotPartLine(x, y + dy, dx);
//            paintDotPartLine(x, y + dy, -dx);
//            paintDotPartLine(x, y - dy, dx);
//            paintDotPartLine(x, y - dy, -dx);
//        }
//    }
//
//    //        ooooooo
//    //     oo         oo
//    //   o               o
//    //  o                 o
//    //  o        X        o
//    //  o                 o
//    //   o       ========o
//    //     oo         oo
//    //        ooooooo
//
//    void paintDotPartLine(int startX, int startY, int length) {
//
//        if ((startY < 0 || startY >= bitmapHeight)) // Check image borders
//            return;
//
////        if (length == 0) {
////            paintDotPixel(startX, startY);
////            return;
////        }
//
//        int dx = (int) Math.signum(length);
//        if (length == 0) {
//            dx = 1;
//        }
//        length = Math.abs(length);
//        for (int x = 0; -length <= x && x <= +length; x += dx) {
//
//            if (startX + x < 0 || startX + x >= bitmapWidth)  // Check image borders
//                return;
//
//            int color = bitmap.getPixel(startX + x, startY);
//
//            if (isEqualColor(color, seekColor)) // Paint on seekColor
//                paintDotPixel(startX + x, startY);
//            else if (!isEqualColor(color, paintColor)) // Continue on paintColor
//                return;  // Stop painting line if other colors
//        }
//    }
//
//    void paintDotPixel(int x, int y) {
//        bitmap.setPixel(x, y, paintColor);
//    }


// =============================================================================================
// Fill Region
// =============================================================================================


//    @Override
//    public void actionFillRegion(float x, float y, @ColorInt int MaskColor) {
//        Bitmap mask = makeAlphaMask(Math.round(x), Math.round(y), bitmap, MaskColor);
//
//    }

// =============================================================================================
// Make Alpha mask of Region
// =============================================================================================

    @ColorInt
//    private static final int MASK_COLOR = Color.alpha(127);
    Stack<Segment> segmentStack = new Stack<>();

    public Bitmap makeAlphaMask(int startX, int startY, Bitmap sourceBitmap, int alphaColor) {

        Bitmap tmpBitmap = Bitmap.createBitmap(sourceBitmap);

        Bitmap alphaBitmap = Bitmap.createBitmap(
                tmpBitmap.getWidth(),
                tmpBitmap.getHeight(),
                Bitmap.Config.ARGB_8888);

        @ColorInt
        int seekColor = tmpBitmap.getPixel(startX, startY);

        int bitmapHeight = tmpBitmap.getHeight();


        // Initial segment
        segmentStack.empty();
        segmentStack.push(
                new Segment(startX, startY)
                        .extendLeftBorder(tmpBitmap)
                        .extendRightBorder(tmpBitmap)
        );


        // Loop over stack
        while (!segmentStack.empty()) {
            Segment next = segmentStack.pop();
Log.d("happy", "Stack size: "+segmentStack.size()+" Segment: "+next.leftX+" "+next.rightX+" "+next.y);
            next.paint(tmpBitmap, seekColor);
            next.paint(alphaBitmap, alphaColor);

            if ((next.direction == FillDirection.UP || next.direction == FillDirection.BOTH) &&
                    next.y - 1 >= 0)
                checkLine(next.leftX, next.rightX, next.y - 1, FillDirection.UP, tmpBitmap, seekColor);

            if ((next.direction == FillDirection.DOWN || next.direction == FillDirection.BOTH) &&
                    next.y + 1 < bitmapHeight)
                checkLine(next.leftX, next.rightX, next.y + 1, FillDirection.DOWN, tmpBitmap, seekColor);
        }

        return alphaBitmap;
    }


    // Split line to Segments and push to stack
    private void checkLine(int leftX, int rightX, int y, FillDirection direction, Bitmap sourceBitmap, @ColorInt int seekColor) {

        Segment tmpSegment = null;

        // checking line
        for (int x = leftX; x <= rightX; x++) {

            // Open segment
            if (tmpSegment == null &&   // no opened segment
                    isEqualColor(sourceBitmap.getPixel(x, y), seekColor)) {   // equal color found

                // Create new segment
                tmpSegment = new Segment(x, y);
            }

            // Close segment
            if (tmpSegment != null &&   // inside segment
                    (!isEqualColor(sourceBitmap.getPixel(x, y), seekColor) || x == rightX)) {
                // right border found || reached last pixel

                // Close segment and push into stack
                tmpSegment.rightX = x - 1;
                tmpSegment
                        .extendLeftBorder(sourceBitmap)
                        .extendRightBorder(sourceBitmap);

                if (tmpSegment.leftX < leftX || tmpSegment.rightX > rightX)
                    tmpSegment.direction = FillDirection.BOTH;
                else tmpSegment.direction = direction;

                segmentStack.push(tmpSegment);
                tmpSegment = null;
            }
        }
    }

    private boolean isEqualColor(@ColorInt int color1, @ColorInt int color2) {
        return color1 == color2;
    }


// =============================================================================================
// Inner Classes
// =============================================================================================

    enum FillDirection {UP, DOWN, BOTH}

    // Segment is a horizontal 1px line filled with single color
    private class Segment {

        int leftX;
        int rightX;
        int y;
        FillDirection direction;


        public Segment(int leftX, int rightX, int y, FillDirection direction) {
            this.direction = direction;
            this.y = y;
            this.rightX = rightX;
            this.leftX = leftX;
        }

        public Segment(int x, int y) {
            this(x, x, y, FillDirection.BOTH);
        }

        private Segment extendLeftBorder(Bitmap b) {
            int color = b.getPixel(leftX, y);
            while (leftX - 1 >= 0 &&
                    isEqualColor(b.getPixel(leftX - 1, y), color)) {
                leftX--;
            }
            return this;
        }

        private Segment extendRightBorder(Bitmap b) {
            int color = b.getPixel(rightX, y);
            int bWidth = b.getWidth();
            while (rightX + 1 < bWidth &&
                    isEqualColor(b.getPixel(rightX + 1, y), color)) {
                rightX++;
            }
            return this;
        }

        private Segment paint(Bitmap b, @ColorInt int color) {
            for (int x = leftX; x <= rightX; x++)
                b.setPixel(x, y, color);
            return this;
        }

    }

}