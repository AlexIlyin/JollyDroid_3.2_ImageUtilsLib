package com.alexilyin.android.a32_imageutilslib.paint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.support.annotation.ColorInt;
import android.view.MotionEvent;
import android.view.Surface;

/**
 * Created by user on 29.03.16.
 */
public interface IPainter {

    void putBitmap(Bitmap bitmap);
    void putSurface(Surface surface);

    void setPaintColor(int color);

    void actionFillRegion(float x, float y, @ColorInt int MaskColor);
    void actionPaintFree(float x, float y);
    void actionPaintInsideRegion(float x, float y);
    void pickStartPoint(float x, float y);
//    void touch(int x, int y);
//
//    void move(int x1, int y1, int x2, int y2);
}
