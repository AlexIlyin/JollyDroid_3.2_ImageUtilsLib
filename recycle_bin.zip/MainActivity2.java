package com.alexilyin.android.a32_imageutilslib;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

public class MainActivity2 extends AppCompatActivity {

    private SurfaceView sv;
    private SurfaceHolder holder;
    private Surface surface;

//    private IPainter painter;

    private Button btnFillRegion;
    private Button btnPaintRegion;
    private Button btnPaintFree;
    private Switch swPaintErase;

    enum PaintTool {FILL_REGION, PAINT_INSIDE_REGION, PAINT_FREE}

    enum PaintMode {PLAIN_COLOR, ERASE}

    PaintTool paintTool;
    PaintMode paintMode;
    MyPainter painter;



    public static final String TAG = "happy";

    /*
     * SufraceView можно использовать только после его инициализации.
     * О ней мы узнает из колбэка
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sv = (SurfaceView) findViewById(R.id.sv);
        assert sv != null;
        holder = sv.getHolder();

        holder.addCallback(callback);

        painter = new MyPainter();

        btnFillRegion = (Button) findViewById(R.id.btnFillRegion);
        btnFillRegion.setOnClickListener(toolButtonsListener);

        btnPaintRegion = (Button) findViewById(R.id.btnPaintRegion);
        btnPaintRegion.setOnClickListener(toolButtonsListener);

        btnPaintFree = (Button) findViewById(R.id.btnPaintFree);
        btnPaintFree.setOnClickListener(toolButtonsListener);

        swPaintErase = (Switch) findViewById(R.id.swPaintErase);
        swPaintErase.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    paintMode = PaintMode.ERASE;
                } else {
                    paintMode = PaintMode.PLAIN_COLOR;
                }
            }
        });

        // Set initial state
        paintTool = PaintTool.PAINT_FREE;
        paintMode = PaintMode.PLAIN_COLOR;
        paintColor = Color.RED;

    }


    View.OnClickListener toolButtonsListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btnFillRegion:
                    paintTool = PaintTool.FILL_REGION;
                    break;
                case R.id.btnPaintRegion:
                    paintTool = PaintTool.PAINT_INSIDE_REGION;
                    break;
                case R.id.btnPaintFree:
                    paintTool = PaintTool.PAINT_FREE;
                    break;
            }
        }
    };

    /*
     * Колбэк.
     * surfaceChanged() будет вызвано как при первом создании, так и при изменении
     */

    SurfaceHolder.Callback2 callback = new SurfaceHolder.Callback2() {
        @Override
        public void surfaceRedrawNeeded(SurfaceHolder holder) {

        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            stopPaint();
            startPaint(width, height);
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            stopPaint();
        }
    };

    /*
     * Рисовать мы будем в Bitmap, затем копировать его в SufraceView.
     * Соответственно, Bitmap надо создать.
     *
     * Переноса уже нарисованной картинки при изменении из старого битмапа в новый нет.
     */

    private Bitmap paperBitmap;
    private Canvas paperCanvas;

    private void startPaint(int width, int height) {
        surface = holder.getSurface();
        paperBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        paperCanvas = new Canvas(paperBitmap);

        tmpBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        tmpCanvas = new Canvas(tmpBitmap);

//        maskBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        porterDuffXfermode = new PorterDuffXfermode(PorterDuff.Mode.DST_IN);

        sv.setOnTouchListener(touchListener);

//        painter.putBitmap(paperBitmap);
    }

    private void stopPaint() {
        sv.setOnTouchListener(null);

        surface = null;

        if (paperBitmap != null) {
            paperBitmap.recycle();
            paperBitmap = null;
            paperCanvas = null;
        }

    }

    /*
     * Обработка касаний. При касании ставим первую точку линии,
     * дальше продолжаем.
     *
     * Касание в нескольких точках не обрабатывается.
     */
    View.OnTouchListener touchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {

            Log.d(TAG, "Touch event - x: " + event.getX() + ", y: " + event.getY());

            switch (paintTool) {
                case FILL_REGION:
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            actionFillRegion(event.getX(), event.getY());

//
//                            maskBitmap = myPainter.makeAlphaMask(
//                                    Math.round(event.getX()),
//                                    Math.round(event.getY()),
//                                    paperBitmap,
//                                    Color.WHITE);
//
//                            Canvas canvas = surface.lockCanvas(null);
//                            canvas.drawBitmap(maskBitmap, 0, 0, null);
//                            surface.unlockCanvasAndPost(canvas);

                            // ===================
//                            Bitmap plainColorBitmap = Bitmap.createBitmap(paperBitmap.getWidth(), paperBitmap.getHeight(), Bitmap.Config.ARGB_8888);
//                            plainColorBitmap.eraseColor(Color.CYAN);
//
//                            Bitmap maskBitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888);
//                            for (int tx = 1; tx < 100; tx++)
//                                for (int ty = 1; ty < 100; ty++)
//                                    maskBitmap.setPixel(tx, ty, Color.MAGENTA);
//
//
//                            Bitmap alphaMask = Bitmap.createBitmap(maskBitmap.getWidth(), maskBitmap.getHeight(), Bitmap.Config.ALPHA_8);
//                            Canvas tmpcanvas = new Canvas(alphaMask);
//                            tmpcanvas.drawBitmap(maskBitmap, 0.0f, 0.0f, null);
//
//                            BitmapShader shader = new BitmapShader(plainColorBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
//                            Paint fillPaint = new Paint();
//                            fillPaint.setAntiAlias(true);
//                            fillPaint.setShader(shader);
//                            fillPaint.setStyle(Paint.Style.FILL);
//
//                            Canvas canvas = surface.lockCanvas(null);
//                            canvas.drawBitmap(alphaMask, 0, 0, fillPaint);
//                            surface.unlockCanvasAndPost(canvas);
//


                            // ===================
//                            painter.putBitmap(paperBitmap);
//                            painter.setPaintColor(Color.GREEN);
//                            painter.putSurface(surface);
//                            painter.actionFillRegion(event.getX(), event.getY());
//                            drawPaperBitmap(event.getX(), event.getY());
                            break;
                    }
                    break;
                case PAINT_INSIDE_REGION:


                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            lastX = event.getX();
                            lastY = event.getY();

                            maskBitmap = painter.makeAlphaMask(
                                    Math.round(event.getX()),
                                    Math.round(event.getY()),
                                    paperBitmap,
                                    Color.WHITE);

//                            Bitmap result = Bitmap.createBitmap(maskBitmap.getWidth(), maskBitmap.getHeight(), Bitmap.Config.ARGB_8888);


                            maskPaint = new Paint();
                            maskPaint.setColor(paintColor);
//        drawPaint.setAntiAlias(true);
                            maskPaint.setStrokeWidth(20);
                            maskPaint.setStyle(Paint.Style.STROKE);
                            maskPaint.setStrokeJoin(Paint.Join.ROUND);
                            maskPaint.setStrokeCap(Paint.Cap.ROUND);


                        case MotionEvent.ACTION_MOVE:

                            maskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));

                            paperCanvas.drawLine(lastX, lastY, event.getX(), event.getY(), maskPaint);



                            maskPaint.setXfermode(null);

                            Canvas canvas = surface.lockCanvas(null);
                            canvas.drawBitmap(paperBitmap, 0, 0, null);
                            surface.unlockCanvasAndPost(canvas);

                            lastX = event.getX();
                            lastY = event.getY();

                            break;
                    }




//                    switch (event.getAction()) {
//                        case MotionEvent.ACTION_DOWN:
////                            painter.putBitmap(paperBitmap);
////                            painter.setPaintColor(Color.YELLOW);
////                            painter.putSurface(surface);
////                            painter.pickStartPoint(event.getX(), event.getY());
//                        case MotionEvent.ACTION_MOVE:
////                            painter.actionPaintInsideRegion(event.getX(), event.getY());
//                            drawPaperBitmap(event.getX(), event.getY());
//                            break;
//                    }
                    break;
                case PAINT_FREE:

//                    switch (event.getAction()) {
//                        case MotionEvent.ACTION_DOWN:
//                            lastX = event.getX();
//                            lastY = event.getY();
//                        case MotionEvent.ACTION_MOVE:
//                            painter.actionPaintFree(event.getX(), event.getY(), lastX, lastY);
//                            lastX = event.getX();
//                            lastY = event.getY();
//                            break;
//                    }


                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
//                        painter.actionPaintFree(event.getX(), event.getY());
                        drawStartDot(event.getX(), event.getY());
                        drawPaperBitmap(event.getX(), event.getY());


                    } else if (event.getAction() == MotionEvent.ACTION_MOVE
                            || event.getAction() == MotionEvent.ACTION_UP) {
                        drawEndDot(event.getX(), event.getY());
                        drawPaperBitmap(event.getX(), event.getY());

                    }
                    break;
            }

            return true;
        }

    };

    /*
     * Инициализация элемента, из которого будет состоять линия
     */

    private int paintColor = 0xffff0000;
    private Paint drawPaint = new Paint();

    {
        drawPaint.setColor(paintColor);
//        drawPaint.setAntiAlias(true);
        drawPaint.setStrokeWidth(20);
        drawPaint.setStyle(Paint.Style.STROKE);
        drawPaint.setStrokeJoin(Paint.Join.ROUND);
        drawPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    /*
     * рисуем точку и линию
     */

    float lastX, lastY;
    @ColorInt
    int replacedColor;

    private void drawStartDot(float x, float y) {
        if (paperCanvas == null) return;

        paperCanvas.drawPoint(x, y, drawPaint);

        drawPaperBitmap(x, y);

    }

    private void drawEndDot(float x, float y) {
        if (paperCanvas == null) return;

        paperCanvas.drawLine(lastX, lastY, x, y, drawPaint);

        drawPaperBitmap(x, y);
    }


    private Bitmap tmpBitmap;
    private Canvas tmpCanvas;
    private Bitmap maskBitmap;
    private Paint maskPaint;
    private PorterDuffXfermode porterDuffXfermode;


    private void actionFillRegion(float x, float y) {
        maskPaint.setXfermode(porterDuffXfermode);

        maskBitmap = painter.makeAlphaMask(
                Math.round(x),
                Math.round(y),
                paperBitmap,
                Color.WHITE);

        tmpCanvas.drawLine(lastX, lastY, x, y, drawPaint);
        tmpCanvas.drawBitmap(maskBitmap, 0, 0, maskPaint);

        maskPaint.setXfermode(null);

        paperCanvas.drawBitmap(tmpBitmap, 0, 0, new Paint());
        drawPaperBitmap(x, y);

        maskBitmap = null;
    }

    /*
     * Копирование битмапа с картинкой в Surface.
     * Прямо в Bitmap от Surface рисовать нельзя - он может прийти, не соответствующий
     * текущему отображаемому состоянию.
     *
     * http://stackoverflow.com/a/36267113/1263771
     */
    private void drawPaperBitmap(float x, float y) {
        Canvas canvas = surface.lockCanvas(null);
        canvas.drawBitmap(paperBitmap, 0, 0, null);
        surface.unlockCanvasAndPost(canvas);

        lastX = x;
        lastY = y;
    }
}
